<?php
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
define('DB_SERVER', 'atsolutions.mysql.dhosting.pl');
define('DB_USERNAME', 'eenoh3_redi');
define('DB_PASSWORD', '0Fh7pu5Ma1dP');
define('DB_NAME', 'be9eif_redilinkinbio');
 
/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
?>